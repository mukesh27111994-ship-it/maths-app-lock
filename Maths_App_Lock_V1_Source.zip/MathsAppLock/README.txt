MATHS APP LOCK - BUILD AND SETUP

1. Extract the complete ZIP to a folder (do not run inside the ZIP).
2. Double click BUILD_APK.bat. Internet is needed on the first build.
3. Wait for SUCCESS. Maths_App_Lock_V1.apk will appear in this folder.
4. Copy the APK to your phone and install it. Android may ask you to allow installation from this source.
5. Open Maths App Lock, tap Enable accessibility service and enable Maths App Lock in Android settings.
6. Return to the app, select a table range and choose one or more apps to protect.
7. Open a protected app and answer the maths question.

Requires Android SDK with platform 35, Java 17 (Android Studio's bundled JDK works), internet to download Gradle and Android build dependencies, and acceptance of SDK licences. If a build reports platform 35 missing, use Android Studio > SDK Manager to install Android 15 (API 35) and Android SDK Build-Tools. For licence errors, open SDK Manager and accept licences.

Samsung: if the service stops, check Settings > Apps > Maths App Lock > Battery and select Unrestricted where available. Settings differ by device.

LIMITATIONS: This is a learning prompt, not a secure lock. Android may briefly display app content before the challenge; users can disable accessibility, uninstall the app, or stop it. Locking system Settings, diallers and this app itself is intentionally unavailable. Some system and manufacturer behaviors may prevent challenge display. There is no parent PIN or Hindi translation in this first version. Accessibility service only checks foreground app package; no screen contents are read and no network permission is requested by the app.

This source has not been compiled or tested on an Android device in this environment. Please test all behavior on your phone. Share any build errors or screenshots for fixes.
