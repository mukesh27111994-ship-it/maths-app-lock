package com.example.mathlock;
import android.app.Activity;
import android.content.*;
import android.content.pm.*;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
 SharedPreferences prefs; LinearLayout root, apps; TextView status; Button permission;
 @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("lock",MODE_PRIVATE);show();}
 @Override protected void onResume(){super.onResume();if(status!=null) status.setText(serviceEnabled()?"Accessibility service: ON":"Accessibility service: OFF — enable to protect apps");}
 boolean serviceEnabled(){String s=Settings.Secure.getString(getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);if(s==null)return false; for(String part:s.split(":")){android.content.ComponentName c=android.content.ComponentName.unflattenFromString(part);if(c!=null && c.getPackageName().equals(getPackageName()) && c.getClassName().equals(LockService.class.getName()))return true;}return false;}
 TextView label(String text,int size){TextView t=new TextView(this);t.setText(text);t.setTextSize(size);t.setTextColor(0xff163b31);t.setPadding(0,18,0,12);return t;}
 void show(){
  ScrollView scroll=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(1);root.setPadding(28,30,28,30);root.setBackgroundColor(0xfff4faf7);scroll.addView(root);setContentView(scroll);
  TextView title=label("🧠 Maths App Lock",27);title.setTextColor(0xff087857);root.addView(title);
  root.addView(label("Solve a quick multiplication before opening selected apps.",15));
  status=label("",15);root.addView(status);
  permission=new Button(this);permission.setText("1. Enable accessibility service");root.addView(permission);permission.setOnClickListener(v->new android.app.AlertDialog.Builder(this).setTitle("Accessibility permission").setMessage("Maths App Lock detects the app currently open so it can display your maths question. It does not read screen contents. Enable Maths App Lock on the next screen.").setNegativeButton("Cancel",null).setPositiveButton("Open settings",(d,w)->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))).show());
  Switch enabled=new Switch(this);enabled.setText("Protection enabled");enabled.setChecked(prefs.getBoolean("enabled",true));enabled.setPadding(0,18,0,18);root.addView(enabled);enabled.setOnCheckedChangeListener((b,on)->prefs.edit().putBoolean("enabled",on).apply());
  root.addView(label("Multiplication tables",18));Spinner range=new Spinner(this);String[] ranges={"2 to 10","2 to 12","2 to 20"};range.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,ranges));int max=prefs.getInt("max",10);range.setSelection(max==20?2:max==12?1:0);root.addView(range);range.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,android.view.View v,int i,long id){prefs.edit().putInt("max",new int[]{10,12,20}[i]).apply();}});
  root.addView(label("Ask again",18));Spinner delay=new Spinner(this);String[] delays={"Every time I leave the app","After 1 minute","After 5 minutes","After 15 minutes"};delay.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,delays));int m=prefs.getInt("delay",0);delay.setSelection(m==1?1:m==5?2:m==15?3:0);root.addView(delay);delay.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,android.view.View v,int i,long id){prefs.edit().putInt("delay",new int[]{0,1,5,15}[i]).apply();LockService.unlocked.clear();}});
  root.addView(label("2. Select apps to protect",20));root.addView(label("Tip: Test with one app first. Do not rely on this as a security password.",14));
  apps=new LinearLayout(this);apps.setOrientation(1);root.addView(apps);loadApps();onResume();
 }
 void loadApps(){PackageManager pm=getPackageManager();Intent intent=new Intent(Intent.ACTION_MAIN);intent.addCategory(Intent.CATEGORY_LAUNCHER);List<ResolveInfo> list=pm.queryIntentActivities(intent,0);Collections.sort(list,(a,b)->a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString()));Set<String> seen=new HashSet<>();for(ResolveInfo r:list){String pkg=r.activityInfo.packageName;if(pkg.equals(getPackageName())||pkg.equals("com.android.settings")||pkg.equals("com.google.android.dialer")||pkg.equals("com.samsung.android.dialer")||!seen.add(pkg))continue;LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(0,8,0,8);ImageView icon=new ImageView(this);icon.setImageDrawable(r.loadIcon(pm));row.addView(icon,new LinearLayout.LayoutParams(70,70));Switch sw=new Switch(this);sw.setText("  "+r.loadLabel(pm));sw.setTextSize(16);sw.setChecked(prefs.getBoolean("app_"+pkg,false));row.addView(sw,new LinearLayout.LayoutParams(-1,-2));sw.setOnCheckedChangeListener((b,on)->{prefs.edit().putBoolean("app_"+pkg,on).apply();LockService.unlocked.remove(pkg);});apps.addView(row);}}
}
