package com.example.mathlock;
import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import java.util.HashMap;

public class LockService extends AccessibilityService {
 static final HashMap<String,Long> unlocked = new HashMap<>();
 static String currentTarget = null, previous = "";
 static boolean challengeVisible = false;
 @Override public void onAccessibilityEvent(AccessibilityEvent e) {
  if (e.getEventType()!=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || e.getPackageName()==null) return;
  String pkg=e.getPackageName().toString();
  if (pkg.equals(getPackageName())) return;
  SharedPreferences p=getSharedPreferences("lock",MODE_PRIVATE);
  if (!pkg.equals(previous)) {
   if (p.getInt("delay",0)==0 && previous.length()>0) unlocked.remove(previous);
   previous=pkg;
  }
  if (!p.getBoolean("enabled",true) || !p.getBoolean("app_"+pkg,false)) return;
  Long until=unlocked.get(pkg);
  if (until!=null && (until==Long.MAX_VALUE || SystemClock.elapsedRealtime()<until)) return;
  if (challengeVisible) return;
  currentTarget=pkg; challengeVisible=true;
  Intent i=new Intent(this,ChallengeActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
  try { startActivity(i); } catch (RuntimeException ex) { challengeVisible=false; }
 }
 @Override public void onInterrupt() { challengeVisible=false; }
 @Override public void onDestroy(){challengeVisible=false; super.onDestroy();}
}
