package com.example.mathlock;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import java.security.SecureRandom;

public class ChallengeActivity extends Activity {
 int answer; String target; boolean granted=false;
 @Override public void onCreate(Bundle b){super.onCreate(b); target=LockService.currentTarget;
  if(target==null){finish();return;}
  SharedPreferences p=getSharedPreferences("lock",MODE_PRIVATE);
  int max=Math.max(2,Math.min(20,p.getInt("max",10))); SecureRandom random=new SecureRandom();
  int a=2+random.nextInt(max-1), c=2+random.nextInt(max-1); answer=a*c;
  LinearLayout l=new LinearLayout(this); l.setOrientation(1);l.setGravity(Gravity.CENTER);l.setPadding(40,40,40,40);l.setBackgroundColor(0xfff2f7f5);
  TextView title=new TextView(this);title.setText("🧠  Maths App Lock");title.setTextColor(0xff0f4335);title.setTextSize(24);l.addView(title);
  TextView prompt=new TextView(this);prompt.setText("Solve to open your app");prompt.setTextSize(18);prompt.setPadding(0,35,0,10);l.addView(prompt);
  TextView q=new TextView(this);q.setText(a+" × "+c+" = ?");q.setTextColor(0xff0b7054);q.setTextSize(42);q.setPadding(0,15,0,25);l.addView(q);
  EditText input=new EditText(this);input.setSingleLine(true);input.setInputType(2);input.setGravity(Gravity.CENTER);input.setTextSize(30);input.setHint("Answer");l.addView(input,new LinearLayout.LayoutParams(-1,-2));
  TextView msg=new TextView(this);msg.setTextColor(0xffb42318);msg.setPadding(0,15,0,15);l.addView(msg);
  Button check=new Button(this);check.setText("Unlock");l.addView(check,new LinearLayout.LayoutParams(-1,-2));
  check.setOnClickListener(v->{String s=input.getText().toString(); if(s.equals(String.valueOf(answer))) { int minutes=p.getInt("delay",0);LockService.unlocked.put(target,minutes==0?Long.MAX_VALUE:SystemClock.elapsedRealtime()+minutes*60000L);granted=true;LockService.challengeVisible=false;finish(); } else {msg.setText("Not quite, try again!");input.setText("");}});
  Button cancel=new Button(this);cancel.setText("Go home");l.addView(cancel);cancel.setOnClickListener(v->goHome());
  setContentView(l);
 }
 void goHome(){Intent home=new Intent(Intent.ACTION_MAIN);home.addCategory(Intent.CATEGORY_HOME);home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(home);finish();}
 @Override public void onBackPressed(){goHome();}
 @Override protected void onDestroy(){LockService.challengeVisible=false;super.onDestroy();}
}
