@echo off
setlocal
cd /d "%~dp0"
echo ================================================
echo Maths App Lock - Android APK Builder
echo ================================================
if not defined ANDROID_HOME if defined ANDROID_SDK_ROOT set "ANDROID_HOME=%ANDROID_SDK_ROOT%"
if not defined ANDROID_HOME set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
if not exist "%ANDROID_HOME%\platforms" (
 echo Android SDK not found at "%ANDROID_HOME%".
 echo Set ANDROID_HOME to your Android SDK folder and run again.
 goto failed
)
if exist "%ProgramFiles%\Android\Android Studio\jbr\bin\java.exe" set "JAVA_HOME=%ProgramFiles%\Android\Android Studio\jbr"
if defined JAVA_HOME set "PATH=%JAVA_HOME%\bin;%PATH%"
java -version >nul 2>&1
if errorlevel 1 (
 echo Java 17 not found. Install Android Studio or set JAVA_HOME to JDK 17.
 goto failed
)
set "GRADLE_DIR=%USERPROFILE%\.maths-applock-build\gradle-8.7"
if exist "%GRADLE_DIR%\bin\gradle.bat" goto build
where powershell >nul 2>&1
if errorlevel 1 (echo PowerShell is required to download Gradle.& goto failed)
echo Downloading Gradle 8.7. Internet is required on first build...
if not exist "%USERPROFILE%\.maths-applock-build" mkdir "%USERPROFILE%\.maths-applock-build"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $f=Join-Path $env:USERPROFILE '.maths-applock-build\gradle-8.7-bin.zip'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.7-bin.zip' -OutFile $f; Expand-Archive -LiteralPath $f -DestinationPath (Split-Path $f) -Force"
if errorlevel 1 goto failed
:build
echo Building debug APK. Android dependencies may download...
call "%GRADLE_DIR%\bin\gradle.bat" --no-daemon assembleDebug
if errorlevel 1 goto failed
if not exist "app\build\outputs\apk\debug\app-debug.apk" goto failed
copy /Y "app\build\outputs\apk\debug\app-debug.apk" "Maths_App_Lock_V1.apk" >nul
echo.
echo SUCCESS: %CD%\Maths_App_Lock_V1.apk
pause
exit /b 0
:failed
echo.
echo BUILD FAILED. Please take a screenshot of the full error and share it.
pause
exit /b 1
